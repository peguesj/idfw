# This file makes the idfw directory a package
from .idfw import main